const express = require('express');
const app = express();
const port = 5000;

app.use(express.json());

app.get('/', (req, res) => {
    res.json({ message: "Welcome to the homepage" });
});

app.get('/about', (req, res) => {
    res.json({ message: "About page" });
});

app.get('/users', (req, res) => {
    res.json({ users: ["user1", "user2", "user3"] });
});

app.post('/message', (req, res) => {
    console.log("Message received:", req.body);
    res.json({ status: "Message received" });
});

app.delete('/user/:id', (req, res) => {
    console.log("Delete user with ID:", req.params.id);
    res.json({ status: `User ${req.params.id} deleted (logged only)` });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});